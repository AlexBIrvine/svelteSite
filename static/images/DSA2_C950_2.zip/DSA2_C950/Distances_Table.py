import csv

class Distances_Table:
    """
    Class representing wgudistance csv
    """
    def __init__(self):
        """
        Default constructor to build distance list
        Parameters are self-explanatory

        Args:
            param: self
        """

        self.list_distances = []

        # retrieves distance csv data by calling self.retrieve_distance
        self.retrieve_distances()

    def retrieve_distances(self, distance_csv='.\Data\wgudistances.csv'):
        """
        A function that retreives distance data from csv file;
        uses all data starting from column index 2 inserts list_distances
        
        Args:
            self: instance
            distance_csv: wgu distances csv file
        Space Time Complexity: O(N)
        """
        
        # returns file, sets alias, specifies file and delimeter
        with open(distance_csv) as distance_csv:
            csv_reader = csv.reader(distance_csv, delimiter=',')

            # generates output, insert into list distances
            for row in csv_reader:
                self.list_distances.append(row[2:])


    def get_all_distances(self, addressID):
        """
        Function that returns a list of distances from addressID

        Args:
            self: instance
            addressID: package address id
        Returns: 
            list of distances
        Space Time Complexity: O(1)
        """
        return self.list_distances[addressID]

    def get_distance(self, from_address, to_address):
        """
        Function to find distance between to address and from address

        Args:
            self: instance
            from_address: address coming from
            to_address: address going to
        Returns: 
            difference in addresses
        Space Time Complexity: O(1)
        """
        return float(self.list_distances[int(from_address)][int(to_address)])

