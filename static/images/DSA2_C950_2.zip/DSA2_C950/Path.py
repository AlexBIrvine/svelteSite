class Edge: 
    """
    Class representing "path" trucks will take between addresses, edges to nodes
    """
    def __init__(self, from_node, to_node, distance):
        """
        Parameterized constructor to build edge class
        Parameters are self-explanatory

        Args:
            param: self
            param: from_node
            param: to_node
            param: distance
        """

        self.from_node = from_node
        self.to_node = to_node
        self.distance = distance