class Package: 
    """
    Class representing characteristics of package
    """
    def __init__(self, PackageID, AddressID, Address, Deadline, City, State, Zip, Weight, Instructions, Status='At Hub'): 
        """
        Parameterized constructor to build packages & subsequent characteristics
        Parameters are self-explanatory

        Args:
            param: self
            param: PackageID
            param: AddressID
            param: Address
            param: Deadline
            param: City
            param: State
            param: Zip
            param: Weight
            param: Instructions
            param: Status
        """
        self.PackageID = PackageID
        self.AddressID = AddressID
        self.Address = Address
        self.Deadline = Deadline
        self.City = City
        self.State = State
        self.Zip = Zip
        self.Weight = Weight
        self.Instructions = Instructions
        self.Status = Status

    def __str__(self):
        """
        String function to represent objects attributes in table format  

        Args: 
            self: instance
        Returns: f string objects attributes
        Space Time Complexity: O(1)
        """
        return f'PackageID = {self.PackageID:2} | AddressID = {self.AddressID:2} | Deadline = {self.Deadline:16} | Instructions = {self.Instructions:60} | Status = {self.Status:10}'

    def __eq__(self, other):
        """
        Built in equality function. Ensures PackageID equal.

        Args:
            self: instance
            other: alias PackageID
        Returns: PackageID Equality
        Space Time Complexity: O(1)
        """
        return self.PackageID == other.PackageID

