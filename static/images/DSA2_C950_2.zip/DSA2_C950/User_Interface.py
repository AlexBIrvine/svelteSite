from Truck import Truck
from Hash import Hashtable
import re
from datetime import datetime
from Package import Package

class User_Interface: 
    """
    Class representing user interface
    """

    def __init__(self, Hub, Truck1, Truck2, Truck3):
        """
        Parameterized constructor to build user interface
        Parameters are self-explanatory

        Args:
            param: self
            param: Hub
            param: Truck1
            param: Truck2
            param: Truck3
        """

        # assign empty string to self.interface, Hub to self.Hub, and Truck 1, 2, and 3 to self.trucks
        self.interface = ''
        self.Hub = Hub
        self.trucks = [Truck1, Truck2, Truck3]

    def refresh(self):
        """
        Function will clear the cli 

        Args:
            self: instance
        Space Time Complexity: O(1)
        """

        # add empty string to self.interface, "overwrite"
        self.interface = ''
        print('\033c')

    def home(self):
        """
        Function will add home text to interface

        Args:
            self: instance
        Space time Complexity: O(1)
        """
        
        # add text to self.interface
        self.interface += """
        Welcome to the WGUPS Delivery Application. 

        Please refer to the user manual with questions or concerns. 
        """

        # print text using self.print
        self.print()

    def menu(self):
        """
        Function will add menu text to interface

        Args:
            self: instance
        Space Time Complexity: O(1)
        """

        # refresh cli using self.refresh
        self.refresh()

        # add text to self.interface
        self.interface += """
        1: Print Current Scenario
        2: Query Deliveries By...
        3: Add Package
        4: Configure Time
        5: Terminate
        """

        # print text using self.print
        self.print()

        
    def scenario(self): 
        """
        Function will add current scenario information to interface. This information will
        be used as an overview.

        Args:
            self: instance
        Space Time Complexity: O(N)
        """
        
        # refresh cli using self.refresh
        self.refresh()

        # for trucks, add text to self.interface
        self.interface += """
        Here is the Current Scenario for this delivery territory...
        """
        for truck in self.trucks:
            self.interface += str(truck)

        self.interface += str(self.Hub)

        # print text using self.print
        self.print()

        # holds display until key entered
        input('Please press enter to continue.')

    def query(self):
        """
        Function will add query selection information to interface menu option 2

        Args:
            self: instance
        Space Time Complexity: O(1)
        """

        # refresh cli using self.refresh
        self.refresh()

        # add text to self.interface
        self.interface += """
        Please define search criteria...
        
        1 - Package Status: At The Hub, En Route, Delivered
        2 - Package ID
        3 - Weight
        4 - Deadline
        5 - Address
        6 - City
        7 - Zip
        """

        # print text using self.print
        self.print()

    def query_status(self):
        """
        Function will add query selection information to interface menu option 2, sub menu
        option 1.

        Args: 
            self: instance
        Space Time Complexity: O(N)
        """

        # refresh cli using self.refresh
        self.refresh()

        # add text to self.interface
        self.interface += """
        Would you like to search by...
        1 - At the Hub?
        2 - En Route?
        3 - Delivered?
        """

        # print text using self.print
        self.print()

        # subinput assign user required input
        subinput = input()

        # refresh cli using self.refresh
        self.refresh()

        # search package by input, add string package into interface, else by input option
        if subinput == 1:
            results = self.Hub.search_package('At the Hub', 'Status') 
            for package in results:
                self.interface += f'{str(package)}\n'
        elif subinput == 2:
            results = self.Hub.search_package('En Route', 'Status')
            for package in results:
                self.interface += f'{str(package)}\n'
        elif subinput ==3:
            results = self.Hub.search_package('Delivered', 'Status')
            for package in results:
                self.interface += f'{str(package)}\n'
        else:
            self.interface += "Please use 1-3 only."

        # print text using self.print
        self.print()

        # holds display until key entered
        input('Please press enter to continue.')

    def query_id(self):
        """
        Function will add query selection information to interface menu option 2, sub menu
        option 2.

        Args: 
            self: instance
        Space Time Complexity: O(N)
        """

        # refresh cli using self.refresh
        self.refresh()

        # add text to self.interface
        self.interface += """
        Please enter Package ID.
        Example input: 5.
        """

        # print text using self.print
        self.print()

        # subinput assign user required input
        subinput = input()

        # search package by PackageID, add text to self.interface
        results = self.Hub.search_package(subinput, 'PackageID') #search package
        for package in results:
            self.interface += f'{str(package)}\n'

        # print text using self.print
        self.print()

    def query_weight(self): 
        """
        Function will add query weight information to interface menu option 2, sub menu
        option 3.

        Args: 
            self: instance
        Space Time Complexity: O(N)
        """

        # refresh cli 
        self.refresh()

        # add text to self.interface
        self.interface += """
        Please enter weight.
        Example input: 40. 
        """

        # print text using self.print
        self.print()

        # subinput assign user required input 
        subinput = input()

        # search package by weight, add text to self.interface
        results = self.Hub.search_package(subinput, 'Weight')
        for package in results:
            self.interface += f'{str(package)}\n'

        # print text using self.print
        self.print()

        # holds display until key entered
        input('Please press enter to continue.')

    def query_deadline(self):
        """
        Function will add query weight information to interface menu option 2, sub menu
        option 4.

        Args: 
            self: instance
        Space Time Complexity: O(N)
        """

        # refresh cli 
        self.refresh()

        # add text to self.interface
        self.interface += """
        What is the package deadline? 
        Example input: 9:00 AM.
        Example input: EOD. 
        """

        # print text using self.print
        self.print()

        # subinput assign user required input
        subinput = input()

        # search package by Deadline, add text to self.interface
        results = self.Hub.search_package(subinput, 'Deadline')
        for package in results:
            self.interface += f'{str(package)}\n'

        # print text using self.print
        self.print()

        # holds display until key entered
        input('Please press enter to continue.')
       
    def query_address(self):
        """
        Function will add query weight information to interface menu option 2, sub menu
        option 5.

        Args: 
            self: instance
        Space Time Complexity: O(N)
        """

        # refresh cli 
        self.refresh()

        # add text to self.interface
        self.interface += """
        Please enter package delivery address.
        Example input: 177 W Price Ave.  
        """

        # refresh cli 
        self.print()

        # subinput assign user required input
        subinput = input()

        # search package by Address, add text to self.interface
        results = self.Hub.search_package(subinput, 'Address')
        for package in results:
            self.interface += f'{str(package)}\n'

        # print text using self.print
        self.print()

        # holds display until key entered
        input('Please press enter to continue.')

    def query_city(self):
        """
        Function will add query weight information to interface menu option 2, sub menu
        option 6.

        Args: 
            self: instance
        Space Time Complexity: O(N)
        """

        # refresh cli 
        self.refresh()

        # add text to self.interface
        self.interface += """
        Please enter package city. 
        Example input: Salt Lake City.
        """

        # print text using self.print
        self.print()

        # subinput assign user required input
        subinput = input()

        # search package by City, add text to self.interface
        results = self.Hub.search_package(subinput, 'City')
        for package in results:
            self.interface += f'{str(package)}\n'

        # print text using self.print
        self.print()

        # holds display until key entered
        input('Please press enter to continue.')

    def query_zip(self):
        """
        Function will add query weight information to interface menu option 2, sub menu
        option 7.

        Args: 
            self: instance
        Space Time Complexity: O(N)
        """

        # refresh cli 
        self.refresh()

        # add text to self.interface
        self.interface += """
        Please enter package zip.
        Example input: 84115.
        """

        # print text using self.print
        self.print()

        # subinput assign user required input
        subinput = input()

        # search package by Address, add text to self.interface
        results = self.Hub.search_package(subinput, 'Zip')
        for package in results:
            self.interface += f'{str(package)}\n'

        # print text using self.print
        self.print()

        # holds display until key entered
        input('Please press enter to continue.')

    def add(self): 
        """
        This function builds functionality into add a package menu option 

        Args:
            self: instance
        Space Time Complexity: O(N)
        """

        # refresh cli using self.refresh
        self.refresh()

        # add text to self.interface
        self.interface += """
        Package added succesfully. 
        """
        
        Address = input('Please enter a package address.')
        Deadline = input('Please enter a package deadline.')
        City = input('Please enter a package city.')
        State = input('Please enter a package state.')
        Zip = input('Please enter a package zip code.')
        Weight = input('Please enter a package weight.')
        Instructions = input('If you have special instructions, please enter here.')
        PackageID = None
        AddressID = None

        # packageid to empty bucket index
        for index, bucket in enumerate(self.Hub.list_packages):
            if bucket == None:
                PackageID = index
                break 
        
        # if search results found, else append into bucket
        results = self.Hub.search_package(Address, 'Address')
        if results:
           AddressID = results[0].AddressID
        else:
            addressids = []
            for bucket in self.Hub.list_packages:
                if type(bucket) == Package:
                    addressids.append(int(bucket.AddressID))
            AddressID = max(addressids) + 1

        # create new package using create_package
        self.Hub.create_package(PackageID, AddressID, Address, Deadline, City, State, Zip, Weight, Instructions)

        # print text using self.print
        self.print()

        # holds display until key entered
        input('Please press enter to continue.')

    def configure(self):
        """
        Function configures time of application with help of configure_sim 

        Args:
            self: instance
        Space Time Complexity: O(1)
        """

        # refresh cli using self.refresh
        self.refresh()

        # add text to self.interface
        self.interface += """"""

        # print text using self.print
        self.print()

        # set_time assign input from user
        Set_time = input('Please enter time in 24H format, "HH:MM". Example - "14:27" = 2:27 PM.')

        # match input format
        match = re.match(r'(\d+)\D+(\d+)',Set_time)

        # If match, configure time. Else, 'please try again.'
        if match and match.lastindex == 2:
            hours = int(match.group(1))
            minutes = int(match.group(2))
            self.configure_sim(datetime(2022,1,1,hours,minutes))
        else:
            self.interface += f'Invalid input, please try again.'

        # print text using self.print
        self.print()

        # holds display until key entered
        input('Please press enter to continue.')

    def configure_sim(self, time):
        """
        This function builds functionality into configure function. Helps user configure time of application.

        Args:
            self: instance
            time: time
        Space Time Complexity: O(1)
        """
        # if time greater than or equal, update package 9
        if time >= datetime(2022,1,1,10,20):
            self.Hub.package_9()
            print('Updating Package 9.')

        # move first and second truck to respective times, if truck 1 or 2 has delivered packages, then we can move 3rd truck
        self.trucks[0].move_truck_time(time)
        self.trucks[1].move_truck_time(time)
        if self.trucks[0].status == 'Complete' or self.trucks[1].status == 'Complete':
            if self.trucks[0].status == 'Complete' and self.trucks[1].status == 'Complete':
                if self.trucks[0].time <= self.trucks[1].time:
                    self.trucks[2].time = self.trucks[0].time
                    self.trucks[2].move_truck_time(time)
                else:
                    self.trucks[2].time = self.trucks[1].time
                    self.trucks[2].move_truck_time(time)
        elif self.trucks[0].status == 'Complete':
            self.trucks[2].time = self.trucks[0].time
            self.trucks[2].move_truck_time(time)
        else:
            self.trucks[2].time = self.trucks[1].time
            self.trucks[2].move_truck_time(time)  

    def terminate(self):
        """
        Function is used to terminate program 

        Args: 
            self: instance
        Space Time Complexity: O(1)
        """

        # refresh cli using self.refresh
        self.refresh()

        # add text to self.interface
        self.interface += """
        Shutting down...
        """

        # print text using self.print
        self.print()

        # quit
        quit()

    def menu_function(self):
        """
        A function used to build functionality into menu interface. We do this by adding input
        and calling the individual interface functions. 

        Args:
            self: instance
        Space Time Complexity: O(1)
        """

        # input
        user_input = int(input('You entered: '))

        # if/elif input == x, call x function, 
        if user_input == 2: 
            self.query()
            subinput = int(input('You entered: '))
            if subinput == 1:                           
               self.query_status()
            elif subinput == 2: 
                self.query_id()
            elif subinput == 3:
                self.query_weight()
            elif subinput == 4:
                self.query_deadline()
            elif subinput == 5:
                self.query_address()
            elif subinput == 6:
                self.query_city()
            elif subinput == 7:
                self.query_zip()

        elif user_input == 1:
            self.scenario()

        elif user_input == 3:
            self.add()

        elif user_input == 4:
            self.configure()

        elif user_input == 5:
            self.terminate()

        # print text using self.print
        self.print()

    def print(self):
        """
        Function to print self.interface

        Args:
            self: instance
        Space Time Complexity: O(1)
        """
        print(self.interface)
