import csv
from multiprocessing.sharedctypes import Value 
from Package import Package  

class Hashtable:  
    """
    Class representing a hash table."
    """
    def __init__(self, size=80):
        """
        Parameterized constructor to build package list, define hashtable size
        Parameters are self-explanatory

        Args:
            param: self
            param: size
        """
       
        self.size = size  
        self.list_packages=[]  
        
        # assign null value to "buckets", append into list_packages
        for i in range(self.size):     
            self.list_packages.append(None) 

        # retrieve & input package csv data by calling self.retrieve_package_csv  
        self.retrieve_package_csv()   
        
    def retrieve_package_csv(self, package_csv='Data/wgupackages.csv'):
        """
        A function that retrieves package data from csv file, inserts into newly created packages

        Args:
            self: instance
            distance_csv: wgu packages csv file
        Space Time Complexity: O(N)
        """

        # returns file, sets alias, specifies file and delimeter
        with open(package_csv) as package_csv: 
            csv_reader = csv.reader(package_csv, delimiter=',')  

            # generates output
            for row in csv_reader:    
                package = Package(row[0],row[1],row[2],row[6],row[3],row[4],row[5],row[7],row[8])   
                
                # inserts package by calling self.insert_package
                self.insert_package(package)     
  
    def hashkey_method(self, key): 
        """
        Function that uses a direct hash to create hash key, passed in argument uses 
        modulo operator to create bucket index on size of table
        

        Args:
            self: instance
            key: calculating value
        Returns: hash key
        Space Time Complexity: O(1)
        """

        return int(key) % self.size  

    def create_package(self, PackageID, AddressID, Address, Deadline, City, State, Zip, Weight, Instructions=''):
        """
        Function that creates package
        Parameters are self-explanatory

        Args:
            param: self
            param: PackageID
            param: AddressID
            param: Address
            param: Deadline
            param: City
            param: State
            param: Zip
            param: Weight
            param: Instructions
        Returns: package 
        Space Time Complexity: O(1)
        """

        self.insert_package(Package(PackageID, AddressID, Address, Deadline, City, State, Zip, Weight, Instructions))    

    def read_package(self, PackageID):
        """
        Function that "reads" the package. First, calls hashkey_method to locate and return specific "bucket" index values. 
        Second, returns package "bucket" inside of list_packages.

        Args:
            self: instance
            PackageID: packages ID
        Returns: bucket in list_packages
        Space Time Complexity: O(1)
        """

        bucket = self.hashkey_method(PackageID)     
        return self.list_packages[bucket]     

    def update_package(self, PackageID, value, attribute='status'):
        """
        Function that updates the package, uses elif to locate desired attributes. First, calls hashkey_method to locate and 
        return specific "bucket" index values. Second, updates attributes of package object by overwriting with value argument.
        
        Args:
            self: instance
            value: new value replacing old value
            attribute: desired value to replace
        Space Time Complexity: O(1)
        """

        # uses package ID with hash function to locate corresponding "bucket"
        bucket = self.hashkey_method(PackageID) 

        # if attribute this, then update value that
        package = self.list_packages[bucket]   
        if attribute == 'address': 
            package.Address = value
        elif attribute == 'deadline':
            package.Deadline = value
        elif attribute == 'city':
            package.City = value
        elif attribute == 'state':
            package.State = value
        elif attribute == 'zip':
            package.Zip = value
        elif attribute == 'weight':
            package.Weight = value
        elif attribute == 'instructions':
            package.Instructions = value
        elif attribute == 'status':
            package.Status = value

        # insert package by calling self.insert_package
        self.insert_package(package)

    def delete_package(self, PackageID):
        """
        Function that deletes a package, First, calls hashkey_method to locate and return 
        specific "bucket" index values. Second, overwrites bucket values by assigning None value, 
        essentially "deletes" package. 
        
        Args:
            self: instance
            PackageID: packages ID
        Space Time Complexity: O(1)
        """
        
        bucket = self.hashkey_method(PackageID)   
        self.list_packages[bucket] = None 

    def insert_package(self, package):
        """
        Function that "inserts" a package. First, calls hashkey_method to locate and return specific
        "bucket" index values. Second, we take the list, but in that index which is bucket, and in 
        that part of that list we are putting in that package.

        Args:
            self: instance
            package: package object
        Space Time Complexity: O(1)
        """

        bucket = self.hashkey_method(package.PackageID)
        self.list_packages[bucket] = package 

    def search_package(self, value, attribute = 'AddressID'): ####
        """
        Function that searches all packages. First, assigns empty search results list. Second, searches
        all packages in hashtable by attribute/ value. Third, returns search results. Elsif repeat by attribute. 

        Args:
            self: instance
            value: specific value
            attribute: category
        Returns: 
            search_results: list of results 
        Space Time Complexity: O(N)
        """
        
        # assign empty list search_results
        search_results = []

        # Search through packages, if match, return. Elseif repeat by attribute.  
        for package in self.list_packages:
            if attribute == 'address':
                if type(package) == Package and package.Address == value:
                    search_results.append(package)
            elif attribute == 'AddressID':
                if type(package) == Package and int(package.AddressID) == value:
                    search_results.append(package)
            elif attribute == 'city':
                if type(package) == Package and package.City == value:
                    search_results.append(package)
            elif attribute == 'zip':
                if type(package) == Package and package.Zip == value:
                    search_results.append(package)
            elif attribute == 'Status':
                if type(package) == Package and package.Status == value:
                    search_results.append(package)

        # returns list of results
        return search_results


    def handload_truck1(self):
        """
        Function loads truck. First, assigns values to packages list. Second, assigns empty list to truck. Third, 
        populates truck. Fourth, returns loaded truck. 

        Args:
            self: instance
        Returns: 
            truck1: loaded truck list
        Space Time Complexity: O(N)
        """
        
        # assign package IDs to packages list
        packages = [11, 12, 21, 1, 40, 23, 27, 35, 29, 9, 28, 24, 2, 7]
        
        # assign empty list to hold truck packages
        truck1 = []

        # populating truck1, reads package contents by calling read_package
        for i in packages:
            truck1.append(self.read_package(i))

        # returns truck list 
        return truck1
         

    def handload_truck2(self):
        """
        Function loads truck. First, assigns values to packages list. Second, assigns empty list to truck. Third, 
        populates truck. Fourth, returns loaded truck. 

        Args:
            self: instance
        Returns: 
            truck2: package loaded truck
        Space Time Complexity: O(N)
        """
        
        # assign Package IDs to packages list
        packages = [5, 10, 13, 14, 15, 16, 19, 20, 34, 31, 36, 37, 38, 39] 
        
        # assign empty list to hold truck packages
        truck2 = []

        # populating truck1, reads package contents by calling read_package
        for i in packages:
            truck2.append(self.read_package(i))

        # returns truck list 
        return truck2

    def handload_truck3(self):
        """
        Function loads truck. First, assigns values to packages list. Second, assigns empty list to truck. Third, 
        populates truck. Fourth, returns loaded truck. 

        Args:
            self: instance
        Returns: 
            truck3: package loaded truck
        Space Time Complexity: O(N)
        """

        # assign Package IDs to packages list
        packages = [4, 6, 17, 22, 26, 32, 33, 3, 18, 25, 8, 30]
        
        # assign empty list to hold truck packages
        truck3 = []

        # populating truck1, reads package contents by calling read_package
        for i in packages:
            truck3.append(self.read_package(i))

        # returns truck list
        return truck3

    def package_9(self): 
        """
        Function configures package 9 persuant to WGU instructions, handles wrong label address. Reads package
        by calling self.read_package, "overwrites" package values, then reinserts package by calling self.insert_package. 

        Args:
            self: instance
        Space Time Complexity: O(1)
        """
        
        # assigns package 9 by using read function finding current values
        package_9 = self.read_package(9)

        # new values
        package_9.Address = '410 S State St.'
        package_9.City = 'Salt Lake City'
        package_9.Zip = '84111'
        package_9.AddressID = 19

        # reinsert package by calling insert_package
        self.insert_package(package_9)

    
    def __str__(self):
        """
        Function to convert values into string, in our case, package objects inside hashtable. Assigns emptry string,
        prints out f string for each object in different list, appends those strings into empty string, and finally
        returns those strings.

        Args:
            self: instance
        Returns: 
            results: string values of self.list_packages 
        Space Time Complexity: O(N)
        """
        
        # assigns empty string to results
        results = ''
        
        # f string for each package object in self.list_packages, store results
        for package in self.list_packages: 
            results += f'{str(package)}\n' 

        # returns new results string
        return results





















