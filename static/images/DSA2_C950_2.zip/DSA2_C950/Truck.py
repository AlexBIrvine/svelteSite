from cmath import inf
from Package import Package
from Hash import Hashtable     
from Distances_Table import Distances_Table
from Path import Edge
import datetime

class Truck:
    """
    Class representing trucks & paths they will take 
    """
    
    def __init__(self, id, packages, departure, hashtable): 
        """
        Parameterized constructor to build truck path
        Parameters are self-explanatory


        Args:
            param: self
            param: id
            param: packages
            param: departure
            param: hashtable
        """
        
        self.packages = hashtable 
        self.address_list = Distances_Table() 
        self.time = departure 
        self.mileage = 0.0 
        self.current_location = 0 
        self.truck_id = id 
        self.active_list_packages = packages 
        self.status = 'At Hub' 
        self.spanning_tree = [] 
        self.next_location = 0.0 

        # get order and delivery "instructions" by calling self.sort_packages
        self.sort_packages() 

        # assign next_location to distance difference of current stop
        self.next_location = self.address_list.get_distance(self.current_location, self.active_list_packages[0].AddressID)

    def sort_packages(self): 
        """
        A function that "wraps" all below functions to sort packages. First uses self.minumum_spanning_tree
        to gather list of "edges". Then uses self.depth_first_search to calculate optimal order of addresses.
        Finally, uses self.convert_address to "convert ids into packages" and put them in a list for our use. 

        Args:
            self: instance
        Space Time Complexity: O(N^2)
        """

        # find "path", list of edges, minimum spanning tree, by calling self.minimum_spanning_tree
        self.minimum_spanning_tree() 

        # assign deliver_order to self.depth_first_search, using that list to define optimal order
        delivery_order = self.depth_first_search() 

        # assign empty list to address_order
        address_order = [] 

        # looping through list to "convert ids into packages"
        for address_id in delivery_order: 
            address_order.extend(self.convert_address(address_id)) 

        # assign address_order to self.active_list_packages
        self.active_list_packages = address_order 

    def convert_address(self, AddressID): ######
        """
        Function is checking for defined matches, when found is "converting" Address IDs into package objects 

        Args: 
            self: instance
            AddressID: package address ID
        Returns: package_list
        Space Time Complexity: O(N)
        """

        # assign empty list to package_list
        package_list = []

        # if match found in list, append package
        for package in self.active_list_packages[:]:
            if int(package.AddressID) == int(AddressID): 
                package_list.append(self.active_list_packages.pop(self.active_list_packages.index(package))) 

        # returns list of packages
        return package_list

    def minimum_spanning_tree(self): 
        """
        In this function, we use prims algorithm: from location, to location, and distance in order to find 
        minimum_spanning_tree. The algorithm ensures that the minimal weight, "distance", is chosen at every opportunity. 

        Args:
            self: instance
        Space Time Complexity: O(N^2)
        """

        # Assign address list with 1 element, 0. Assign edges_list empty list. Assign shortest_edges empty list. 
        addresses = [0]
        
        # getting list of addresses, if id not in list, append
        for package in self.active_list_packages: 
            if package.AddressID not in addresses: 
                addresses.append(int(package.AddressID))

        address_count = len(addresses)
        edges_count = 0
        visited = [0] * address_count
        visited[0] = True

        while edges_count < address_count - 1:
            to_node = 0
            from_node = 0
            least_distance = float('inf')

            for i in range(address_count):
                if visited[i]:
                    
                    for j in range(address_count):
                        address_1 = int(addresses[i])
                        address_2 = int(addresses[j])

                        if ((not visited[j]) and self.address_list.get_distance(address_1, address_2)!=0):
                            if least_distance > self.address_list.get_distance(address_1, address_2):
                                least_distance = self.address_list.get_distance(address_1, address_2)
                                from_node = address_1
                                to_node = address_2 

            edge = Edge(from_node, to_node, least_distance)
            self.spanning_tree.append(edge) 

            visited[addresses.index(to_node)] = True
            edges_count = edges_count + 1


    # def minimum_spanning_tree(self): 
    #     """
    #     In this function, we use prims algorithm: from location, to location, and distance in order to find 
    #     minimum_spanning_tree. The algorithm ensures that the minimal weight, "distance", is chosen at every opportunity. 

    #     Args:
    #         self: instance
    #     Space Time Complexity: O(N^2)
    #     """

    #     # Assign address list with 1 element, 0. Assign edges_list empty list. Assign shortest_edges empty list. 
    #     addresses = [0]
    #     edges_list = []
    #     shortest_edges = []
        
    #     # getting list of addresses, if id not in list, append
    #     for package in self.active_list_packages: 
    #         if package.AddressID not in addresses: 
    #             addresses.append(package.AddressID)

    #     # populating edges list by appending all objects
    #     for i in range(len(addresses)):
    #         for j in range(i + 1,len(addresses)):
    #             edge = Edge(addresses[i],addresses[j],self.address_list.get_distance(addresses[i],addresses[j]))   
    #             edges_list.append(edge)

    #     # if edges_list not empty
    #     while (edges_list):

    #         # create a list of unvisited "addresses", and visited nodes
    #         visited_nodes = []
    #         least_distance = float('inf')
    #         shortest_edge = None 

    #         # find the shortest edge that contains a node that we have not visited yet 
    #         for edge in edges_list:
    #             if float(edge.distance) < float(least_distance):         
    #                 least_distance = edge.distance
    #                 shortest_edge = edge
            
    #         # when shortest edge found, move that edge from the edge list to shortest edges list and update nodes
    #         # checking to see if shortest edge has node we have not visited yet
    #         edges_list.remove(shortest_edge) 
    #         if (shortest_edge.from_node not in visited_nodes) or (shortest_edge.to_node not in visited_nodes): 
    #             shortest_edges.append(shortest_edge) 
    #             visited_nodes.append(shortest_edge.from_node)
    #             visited_nodes.append(shortest_edge.to_node)

    #     # assign shortest_edges to self.spanning_tree    
    #     self.spanning_tree = shortest_edges


    def depth_first_search(self):
        """
        In this function, we use an algorithm to search through minimum_spanning_tree. It will help us decide order of packages. 
        We will use empty lists to traverse unvisited nodes until there are none left. 

        If we don't find an edge to visit it's because all nodes have been visited and we now need to backtrack.

        Args:
            self: instance
        Returns: 
            visited_node
        Space Time Complexity: O(N^2)
        """

        # assign 0 to current_node, and empty lists to both visited_node & unvisited_node 
        current_node = 0  
        visited_node = []  
        unvisited_node = [] 

        # populates unvisited_node by appending package.address_id
        for package in self.active_list_packages:
            if package.AddressID not in unvisited_node: 
                unvisited_node.append(int(package.AddressID))
                
        # While we still have unvisited nodes, as we come accross them, we will move to node, remove node 
        # from unvisited_node, and append to visited_node
        while(unvisited_node):
            node_found = False
            for edge in self.spanning_tree:
                if (edge.from_node == current_node) and (edge.to_node not in unvisited_node): 
                    current_node = edge.to_node
                    visited_node.append(int(current_node))
                    unvisited_node.remove(int(current_node))
                    node_found = True

            # if we go through all edges and don't find an edge to visit
            # that means we are at the end of a branch and need to backtrack
            if node_found == False:
                for edge in self.spanning_tree:
                    if edge.to_node == current_node:
                        current_node = edge.from_node
                        break

        # append visited node
        # return visited node
        visited_node.append(0) 
        return visited_node


    def move_truck_miles(self, miles):
        """
        Function that helps "move" our trucks. We call self.travel to move mileage by .1 each call. 

        Args:
            self: instance
            miles: miles
        Space Time Complexity: O(1)
        """

        # assign total_miles to self.mileage + miles
        total_miles = round(self.mileage + miles, 1)

        # While miles, call travel to move truck forward .1. Else, self.status = Complete, break.
        while(total_miles > self.mileage): 
            if self.active_list_packages:
                self.travel()              
            else:
                self.status = 'Complete'
                break

    def move_truck_time(self, time):
        """
        Function that helps "move" our trucks. We call self.travel to move mileage by .1 each call. 

        Args:
            self: instance
            time: time
        Space Time Complexity: O(1)
        """

        # While time, call travel to move truck forward .1. Else, f string completed at x time, break. 
        while(time > self.time):
            if self.active_list_packages:
                self.travel()
            else:
                self.status = f'Completed at: {self.time}'
                break


    def travel(self):  
        """
        Function that moves truck .1 miles. If truck arrives at a destination, deliver package. Uses mileage and location comparison 
        off rounded values. 

        Args:
            self: instance
        Space Time Complexity: O(1)
        """

        # assign 200 to seconds
        SECONDS = 200


        # if mileage is equal to next location, deliver package
        if round(self.mileage,1) == round(self.next_location,1):
            self.deliver_package()
        
        # else continue moving truck forward by .1, print update
        else: 
            self.mileage += .1
            self.mileage = round(self.mileage, 1)
            self.time += datetime.timedelta(0, SECONDS * .1)
            self.status = f"Miles to next. {self.next_location}. \t Miles driven: {self.mileage}. \t Packages Left: {len(self.active_list_packages)}"

    def deliver_package(self):
        """
        Function that "delivers" package. 

        Args:
            self: instance
        Space Time Complexity: O(1)
        """
        
        # pop current package, update package, print string
        self.current_location = self.active_list_packages[0].AddressID 
        self.packages.update_package(self.active_list_packages[0].PackageID, f"delivered at {self.time} on truck# {self.truck_id}") 
        self.active_list_packages.pop(0)

        # if packages remaining, calculate distance until next address
        if self.active_list_packages:
            self.next_location += self.address_list.get_distance(self.current_location, self.active_list_packages[0].AddressID)  

    def __str__(self):
        """
        String method to represent objects in table format. Print out status of truck itself, all packages on truck.

        Args:
            self: instance
        Returns: results
        Space Time Complexity: O(1)
        """

        results = f'{self.status}\n'
        return results

        



