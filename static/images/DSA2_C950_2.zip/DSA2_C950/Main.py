from Truck import Truck
from Hash import Hashtable
from datetime import datetime
from User_Interface import User_Interface



def main():
    """ 
    Main function of program, initializes all, prompts with interface. 
    """

    # assign Hashtable to Hub, truck 1, 2, and 3 to respective functions, and user_interface to all. 
    Hub = Hashtable()
    truck1 = Truck(1, Hub.handload_truck1(), datetime(2022,1,1,8,0), Hub)
    truck2 = Truck(2, Hub.handload_truck2(), datetime(2022,1,1,8,0), Hub)
    truck3 = Truck(3, Hub.handload_truck3(), datetime(2022,1,1,23,59), Hub)

    ui = User_Interface(Hub, truck1, truck2, truck3)

    ui.home()

    while True:
        ui.menu()
        ui.menu_function()

# trucks delivery order
if __name__ == '__main__': 
    main()

