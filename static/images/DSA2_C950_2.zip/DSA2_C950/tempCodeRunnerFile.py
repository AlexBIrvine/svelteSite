
    Main function of program, init